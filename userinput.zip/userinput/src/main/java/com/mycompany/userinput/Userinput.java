/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.userinput;

import java.util.Scanner;

/**
 *
 * @author lsphe
 */
public class Userinput {
    
    
    
    public static void main(String[] args) {
        
        //creating a new scanner to accept user input
        Scanner input = new Scanner(System.in);
        
        // asking the user for their name
        System.out.println("Enter your name: ");
        String name = input.nextLine();
        
        //Display the entered name
        System.out.println("Hello, " + name + "!");

     
    }
}
